GIVA x ZEPTO - SANTA MAGNET AR (MindAR, plain HTML, free hosting)

WHAT CHANGED IN THIS VERSION
- assets/santa-target.jpg is now the clean landscape magnet artwork (1921x1524), not the 280x280 square.
- assets/santa-animation.mp4 re-encoded to the same landscape shape (1008x800), so it no longer stretches in AR.
- AR plane height set to 0.793 to match the magnet.
- AR button shows a clear message if santa-target.mind is missing.

FILES
- index.html  = customer page (Start screen -> camera -> animation over the magnet -> Shop button)
- test.html   = earlier test page with storyboard preview
- assets/     = santa-target.jpg, santa-animation.mp4, santa-target.mind (you add)

TRACKING FILE (already included: assets/santa-target.mind, compiled from santa-target.jpg). To rebuild it:
1. Open https://hiukim.github.io/mind-ar-js-doc/tools/compile/
2. Upload assets/santa-target.jpg  (best: a flat, glare-free photo of the real printed magnet)
3. Click Start, wait, then Download. Rename the download to santa-target.mind
4. Put it in assets/ next to the other files.

TEST
- Camera needs HTTPS or localhost. Locally:  python3 -m http.server 8000  then open http://localhost:8000
- For phones, host on GitHub Pages (free, HTTPS): repo -> Settings -> Pages -> main / root.
- Open the page, tap "Start camera AR test", allow the camera, point at the magnet.

KNOWN LIMITS
- The video has a plain background, so in AR it covers the magnet while playing (it is not a transparent overlay).
- The video is stills with crossfades, not full character animation.
- The magnet art has big flat white/red areas, which track less reliably; check the compiler's feature preview and test on real phones (Android Chrome, iOS Safari) before launch.
- Libraries load from jsdelivr/aframe.io CDNs; for campaign day, host copies locally.
